game = "start"
get_out = 10
againg = True
while game == "start":
    while againg :
        result = "survive"
        if result == "survive":####
            get_out += 10 ####
            if 10 < get_out < 20 :
                print("againe")
            elif get_out > 10 :
                ####
                print("get_out")
                break####
            else :####
                print("die")####
    break